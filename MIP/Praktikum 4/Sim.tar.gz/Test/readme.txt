Dieser Ordner beinhaltet 2 Artefakte.
sim.jar: Die Simulation als executable jar.
native: ordner mit nativen lwjgl (Lightweight Java Game Library) libraries.

Um die Simulation zu starten muß java mit den für das jeweilige System spezifischen nativen lwjgl libraries gestartet werden. Diese können entweder im System installiert werden (hier nicht behandelt) oder der JVM als Parameter mitgegeben werden, siehe unten. 

Das korrekte commando sieht (shell befindet sich im ordner) so aus:
java -Djava.library.path=native/linux -jar sim.jar 

Für linux muß das korrekte OS eingesetzt werden also auf macos z.b. 
java -Djava.library.path=native/macosx -jar sim.jar  
